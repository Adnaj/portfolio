import React from 'react';

const About = () => {
    return (
        <div name='about' className='w-full py-24 md:h-screen bg-[#0d1224] text-[#e5e7eb]'>
            <div className='flex flex-col justify-center items-center w-full h-full'>
                <div className='max-w-[1000px] w-full grid grid-cols-2 gap-8'>
                    <div className='sm:text-right pb-8 pl-4'>
                        <p className='text-4xl text-white font-bold inline border-b-4 border-pink-600'>
                            About
                        </p>
                    </div>
                    <div></div>
                </div>
                <div className='max-w-[1000px] w-full grid sm:grid-cols-2 gap-8 px-4'>
                    <div className='sm:text-right text-4xl font-bold'>
                        <p>Hi. I'm Adnaj, nice to meet you. Please take a look around.</p>
                    </div>
                    <div>
                        <p>Proven ability to transform complex business requirements into reliable, scalable, and user-centric software solutions while collaborating with cross-functional teams to drive digital transformation and operational efficiency. Passionate about writing clean, efficient code and leveraging emerging technologies to build impactful products that deliver measurable business value.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default About;
